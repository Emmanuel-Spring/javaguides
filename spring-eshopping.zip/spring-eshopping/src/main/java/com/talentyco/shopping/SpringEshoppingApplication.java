package com.talentyco.shopping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringEshoppingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringEshoppingApplication.class, args);
	}

}
