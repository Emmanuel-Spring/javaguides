package com.talentyco.stream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreamApiTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
