package com.talentyco.stream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamApiTutorialApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreamApiTutorialApplication.class, args);
	}

}
